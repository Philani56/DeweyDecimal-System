﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ST10083213._PROG7312_POE___TASK_2.Model;

namespace ST10083213._PROG7312_POE___TASK_2
{
    //--------------------------- Code Attrribution ----------------------------
    //This code was contribued in:
    //Author: Moo ICT – Project Based Tutorials
    //Title: WPF C# Tutorial – Create a simple quiz game in Visual Studio
    //Year: 2023
    //URL: https://www.mooict.com/wpf-c-tutorial-create-a-simple-quiz-game-in-visual-studio/

    //This code was contribued in:
    //Author: StackOverflow
    //Title: Creating a random Generator from a text file on c#
    //Year:  15 October 2023
    //URL: https://stackoverflow.com/questions/52418464/creating-a-random-generator-from-a-text-file-on-c-sharp

    //This code was contribued in:
    //Author: c-sharpcorner
    //Title: Progress Bar In WPF
    //Year: 
    //URL: https://www.c-sharpcorner.com/article/progress-bar-in-wpf/#:~:text=This%20is%20the%20real%20time%20value%20that%20shows%20the%20progress.&text=The%20lower%20limit%20value%20we,stay%20in%20its%20lower%20limit.

    //This code was contribued in:
    //Author: StackOverflow
    //Title: How to save data from WPF application to file?
    //Year: 2023
    //URL: https://stackoverflow.com/questions/56919566/how-to-save-data-from-wpf-application-to-file

    public partial class CallNumbers : Window
    {

        // Declare a private list to store QuizData objects
        private List<QuizData> quizData;

        // Declare an integer to keep track of the current question index
        private int currentQuestionIndex;

        // Declare a Random object to generate random numbers for quiz-related operations
        private Random random;


        public CallNumbers()
        {
            
            InitializeComponent();
            InitializeQuizData();
            random = new Random();
            LoadNextQuestion();

        }

        private void InitializeQuizData()
        {
            // Load Dewey Decimal classification data from a file
            
            string filePath = "dewey_decimal_system.txt";
            quizData = LoadDataFromFile(filePath);
        }

        private List<QuizData> LoadDataFromFile(string filePath)
        {
            // Create a list to store QuizData objects
            List<QuizData> data = new List<QuizData>();

            try
            {
                // Read all lines from the specified file
                string[] lines = File.ReadAllLines(filePath);

                // Iterate through each line in the file
                foreach (string line in lines)
                {
                    // Split the line into parts using space as the delimiter
                    string[] parts = line.Split(' '); // Assuming space is the delimiter

                    // Check if the line has the expected format (2 parts)
                    if (parts.Length == 2)
                    {
                        // Extract callNumber and description from the parts
                        string callNumber = parts[0];
                        string description = parts[1];

                        // Create a QuizData object and add it to the list
                        QuizData quizEntry = new QuizData { CallNumber = callNumber, Description = description };
                        data.Add(quizEntry);
                    }
                    // Add additional logic if needed for a different data format
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions that may occur during file reading
                Console.WriteLine($"Error reading file: {ex.Message}");
                // You might want to log the exception or take appropriate action
            }

            // Return the list of QuizData objects
            return data;
        }


        private void LoadNextQuestion()
        {
            if (currentQuestionIndex < quizData.Count)
            {
                QuizData currentQuestion = quizData[currentQuestionIndex];

                // Display the question and options in the UI
                DisplayQuestion(currentQuestion);

                currentQuestionIndex++;
            }
            else
            {
                // Quiz completed
                MessageBox.Show("Quiz Completed!");
                this.Close();
            }
        }

        private void DisplayQuestion(QuizData question)
        {
            // Update UI elements based on the current question
            textBlockThirdLevDes.Text = question.Description;

            // Get four random options (one correct and three incorrect)
            List<QuizData> options = GetRandomOptions(question);

            // Display options in UI buttons
            topLeveltbn1.Content = options[0].CallNumber;
            topLeveltbn2.Content = options[1].CallNumber;
            topLeveltbn3.Content = options[2].CallNumber;
            topLeveltbn4.Content = options[3].CallNumber;
        }

        private List<QuizData> GetRandomOptions(QuizData correctAnswer)
        {
            // Get three incorrect options randomly
            List<QuizData> incorrectOptions = quizData
                .Where(q => q != correctAnswer)
                .OrderBy(_ => random.Next())
                .Take(3)
                .ToList();

            // Add correct answer to the list
            List<QuizData> options = new List<QuizData>(incorrectOptions);
            options.Add(correctAnswer);

            // Shuffle the options
            options = options.OrderBy(_ => random.Next()).ToList();

            return options;
        }

        private void RandomCallNumberBtn_Click(object sender, RoutedEventArgs e)
        {
            // Display a random call number
            if (quizData.Count > 0)
            {
                int randomIndex = random.Next(quizData.Count);
                MessageBox.Show($"Random Call Number: {quizData[randomIndex].CallNumber}");
            }
            else
            {
                MessageBox.Show("No quiz data available.");
            }
        }

        private void RandomDescriptionBtn_Click(object sender, RoutedEventArgs e)
        {
            // Display a random book description
            if (quizData.Count > 0)
            {
                int randomIndex = random.Next(quizData.Count);
                MessageBox.Show($"Random Description: {quizData[randomIndex].Description}");
            }
            else
            {
                MessageBox.Show("No quiz data available.");
            }
        }

        private void RandomizeOptionsBtn_Click(object sender, RoutedEventArgs e)
        {
            // Randomize the options in the UI buttons
            QuizData currentQuestion = quizData[currentQuestionIndex];
            List<QuizData> options = GetRandomOptions(currentQuestion);

            // Display randomized options in UI buttons
            topLeveltbn1.Content = options[0].CallNumber;
            topLeveltbn2.Content = options[1].CallNumber;
            topLeveltbn3.Content = options[2].CallNumber;
            topLeveltbn4.Content = options[3].CallNumber;
        }



        private void topLeveltbn_Click(object sender, RoutedEventArgs e)
        {
            // Handle user's answer selection
            Button clickedButton = (Button)sender;
            string selectedOption = clickedButton.Content.ToString();

            // Check if the selected option is correct
            if (IsCorrectOption(selectedOption))
            {
                // User selected the correct option, load the next question
                LoadNextQuestion();
                IncrementProgressBar();
            }
            else
            {
                // User selected the wrong option, handle accordingly
                MessageBox.Show("Wrong Answer! Try Again.");
                
                // this.Close();
            }

        }

        private void IncrementProgressBar()
        {
            // Increment progress bar value (adjust the increment as needed)
            progressBar.Value += 20; 
            
        }

        private bool IsCorrectOption(string selectedOption)
        {
            // Get the correct answer for the current question
            string correctAnswer = quizData[currentQuestionIndex].CallNumber;

            // Check if the selected option is the correct answer
            return selectedOption == correctAnswer;

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win1 = new MainWindow();
            win1.Show(); //View to the XAML Window Form
            this.Close(); //Close MainWindow Form
        }
    }
    //--------------------------- END Attrribution ----------------------------
}
