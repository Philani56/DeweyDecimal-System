﻿using ST10083213._PROG7312_POE___TASK_1.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ST10083213._PROG7312_POE___TASK_2
{
    /// <summary>
    /// Interaction logic for ReplacingBooks.xaml
    /// </summary>
    public partial class ReplacingBooks : Window
    {
        //--------------------------- Code Attrribution ---------------------------
        //This code was contribued in:
        //Author: WPF Tutorial
        //Title: The DispatcherTimer
        //Year: 2022
        //URL: https://wpf-tutorial.com/misc/dispatchertimer/ 

        //Declaration of variables
        ListBox dragSource = null;
        List<int> items = new List<int>();
        List<String> items2 = new List<String>();
        int pointsbase = 0;
        DispatcherTimer dispatcherTimer = new DispatcherTimer();
        //--------------------------- End Attrribution ---------------------------

        public ReplacingBooks()
        {
            InitializeComponent();
        }

        private void Window_MouseDown(object send, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        //Method to load data into the first ListBox
        private void loadData(object sender, RoutedEventArgs e)
        {
            DALRandomCallNums.generateCallNumbers();
            items2.AddRange(ListNums.callNums);
            foreach (String nums in items2)
            {
                listBox.Items.Add(nums);
            }
        }

        //--------------------------- Code Attrribution ---------------------------
        //This code was contribued in:
        //Author: Patra, D.
        //Title: Drag And Drop Item in ListBox in WPF
        //Year: 2010
        //URL: https://www.c-sharpcorner.com/uploadfile/dpatra/drag-and-drop-item-in-listbox-in-wpf/

        //ListBox Method
        private void ListBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ListBox parent = (ListBox)sender;
            dragSource = parent;
            object data = GetDataFromListBox(dragSource, e.GetPosition(parent));

            if (data != null)
            {
                //Drag and drop the item into a ListBox put on.
                DragDrop.DoDragDrop(parent, data, DragDropEffects.Move);
            }

        }

        //--------------------------- Code Attrribution ---------------------------
        //This code was contribued in:
        //Author: SingletonSean
        //Title: ListViews - WPF DRAG DROP TUTORIAL #3
        //Year: 28 Aug 2021
        //URL: https://www.youtube.com/watch?v=U9P2Bg7u5uA

        #region GetDataFromListBox(ListBox,Point)
        //Get Data from the ListBox which applies to both ListBox 1 and 2.

        //https://www.c-sharpcorner.com/uploadfile/dpatra/drag-and-drop-item-in-listbox-in-wpf/ Diptimaya Patra

        private static object GetDataFromListBox(ListBox source, Point point)
        {
            UIElement? element = source.InputHitTest(point) as UIElement;
            if (element != null)
            {
                object data = DependencyProperty.UnsetValue;
                while (data == DependencyProperty.UnsetValue)
                {
                    data = source.ItemContainerGenerator.ItemFromContainer(element);

                    if (data == DependencyProperty.UnsetValue)
                    {
                        element = VisualTreeHelper.GetParent(element) as UIElement;
                    }

                    if (element == source)
                    {
                        return null;
                    }
                }

                if (data != DependencyProperty.UnsetValue)
                {
                    return data;
                }
            }

            return null;
        }
        //--------------------------- End Attrribution ---------------------------

        //--------------------------- Code Attrribution ---------------------------
        //This code was contribued in:
        //Author: Patra, D.
        //Title: Drag And Drop Item in ListBox in WPF
        //Year: 2010
        //URL: https://www.c-sharpcorner.com/uploadfile/dpatra/drag-and-drop-item-in-listbox-in-wpf/

        //A method to retrieve the data from the item that was dropped into the ListBox. Applies to both ListBox 1 and 2

        private void ListBox_Drop(object sender, DragEventArgs e)
        {
            ListBox parent = (ListBox)sender;
            object data = e.Data.GetData(typeof(string));
            dragSource.Items.Remove(data);
            //((IList)dragSource.ItemsSource).Remove(data);
            parent.Items.Add(data);
        }
        #endregion

        //--------------------------- End Attrribution ---------------------------

        //Back Click Buuton Method
        private void backButton_click(object sender, RoutedEventArgs e)
        {
            MainWindow win2 = new MainWindow();
            win2.Show(); //View to the XAML Window Form
            this.Close(); //Close Replacing Books Window Form
            ListNums.nums.Clear(); //Clear the list
            ListNums.callNums.Clear();
        }

        //--------------------------- Code Attrribution ---------------------------
        //This code was contribued in:
        //Author: W3Schhol Resource
        //Title: C#: Sorts the strings of an array using bubble sort
        //Year: May 11 2023 
        //URL: https://www.w3resource.com/csharp-exercises/string/csharp-string-exercise-12.php

        // BubbleSort Method
        public class BubbleSort
        {
            //A Method for switching the string List using BubbleSort
            public static void Sort(List<string> array)
            {
                for (int i = 0; i < array.Count; i++)
                {
                    for (int j = 0; j < array.Count - 1; j++)
                    {
                        if (array[j].CompareTo(array[j + 1]) > 0)
                        {
                            Swap(array, j, j + 1);
                        }
                    }
                }
            }

            //Method to swap the elements in the first and second in the array selected.
            private static void Swap(List<string> array, int first, int second)
            {
                string temp = array[first];
                array[first] = array[second];
                array[second] = temp;
            }
        }


        //Button you can press to finish the adjustments you've made.
        private void buttonCommit_click(object sender, RoutedEventArgs e)
        {
            BubbleSort.Sort(ListNums.callNums);
            if (listBoxResult.Items.Count == 10)
            {
                ICollection tempList = listBoxResult.Items;
                List<String> listCallNums = new List<String>();
                listCallNums.AddRange(listBoxResult.Items.Cast<String>().ToList());
                bool n = DALRandomCallNums.CompareList(listCallNums); //Boolean to compare the sorted List to list submitted by the user.
                if (n == true)
                {
                    if (progressBar.Value < 100)
                    {
                        ListNums.callNums.Clear();
                        listBox.Items.Clear();
                        listBoxResult.Items.Clear();
                        MessageBox.Show("Sucessful match."); //display to the user if the successful match
                        DALRandomCallNums.generateCallNumbers(); //generate random numbers
                        progressBar.Value += 10;
                        progressBarText.Text = progressBar.Value + "%";
                        pointsbase += 20;
                        string st = "points : " + pointsbase;
                        points.Content = st;
                        if (progressBar.Value == 100)
                        {
                            MessageBox.Show("Game complete"); //Game completed
                            MessageBox.Show("Points : " + pointsbase);
                            //MainWindow Method
                            ReplacingBooks win1 = new ReplacingBooks();
                            win1.Show(); //View to the XAML Window Form
                            this.Close(); //Close MainWindow Form
                        }
                        else
                        {
                            foreach (String nums in ListNums.callNums)
                            {
                                listBox.Items.Add(nums);
                            }
                        }

                    }
                    else
                    {
                        MessageBox.Show("Game complete"); //display messagebox to the user when the game is completed
                    }
                }
                else
                {

                    MessageBox.Show("Incorrect match, please try again"); //display messagebox to the user to show the Incorrect match
                    String listCorrectOrder = "";
                    foreach (String nums in ListNums.callNums)
                    {
                        listCorrectOrder += nums + "\n";
                    }
                    MessageBox.Show("Correct Order" + "\n" + listCorrectOrder); //List of Correct Order
                    ListNums.callNums.Clear();
                    listBox.Items.Clear();
                    listBoxResult.Items.Clear();
                    progressBar.Value -= 10;
                    pointsbase -= 5;
                    string st = "points : " + pointsbase;
                    points.Content = st;

                    if (progressBar.Value < 0 || pointsbase < 0)
                    {
                        MessageBox.Show("Game over"); //display messagebox to the user to show the game is over
                        MessageBox.Show("Points : " + pointsbase); //show user point

                        ReplacingBooks win1 = new ReplacingBooks();
                        win1.Show(); //View to the XAML Window Form
                        this.Close(); //Close MainWindow Form
                    }
                    else
                    {
                        DALRandomCallNums.generateCallNumbers(); //generate call numbers
                        foreach (String nums in ListNums.callNums)
                        {
                            listBox.Items.Add(nums); //Add to the Listbox
                        }
                    }


                }

            }
            else
            {
                MessageBox.Show("Please complete the listbox"); //display messagebox to the user to fill out the Listbox
            }

        }

        private void listBox_isChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }
    }
}
//--------------------------- End Attrribution ---------------------------
