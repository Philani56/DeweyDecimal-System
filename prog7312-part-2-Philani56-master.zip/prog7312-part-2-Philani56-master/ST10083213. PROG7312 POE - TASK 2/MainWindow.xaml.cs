﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ST10083213._PROG7312_POE___TASK_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_MouseDown(object send, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        //Minimze Click Button Method
        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized; //Minimze the Application
        }

        //Close Click Button Method
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown(); //Close the Application
        }

        //Replacing Books Click Buuton Method
        private void btnReplacingBooks_Click(object sender, RoutedEventArgs e)
        {
            ReplacingBooks win1 = new ReplacingBooks();
            win1.Show(); //View to the XAML Window Form
            this.Close(); //Close MainWindow Form
        }

        //Identyfing Books Click Button Method
        private void btnIndentifying_Click(object sender, RoutedEventArgs e)
        {
            IdentifyingAreas win2 = new IdentifyingAreas();
            win2.Show(); //View to the XAML Window Form
            this.Close(); //Close MainWindow Form
        }

        //Call Numbers Click Buuton Method
        private void btnCall_Numbers_Click(object sender, RoutedEventArgs e)
        {
            CallNumbers win3 = new CallNumbers();
            win3.Show(); //View to the XAML Window Form
            this.Close(); //Close MainWindow Form
        }

    }
}