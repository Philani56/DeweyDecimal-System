﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10083213._PROG7312_POE___TASK_2.Model
{
    public class QuizData
    {
        //--------------------------- Code Attrribution ----------------------------
        //This code was contribued in:
        //Author: Coffee Cup Dev
        //Title: C# - How to create a class, objects and add members to the class.
        //Year: 28 Feb 2021
        //URL: https://www.youtube.com/watch?v=XbDwLbPHIdw

        public string Description { get; set; }
        public string CallNumber { get; set; }
    }
}
