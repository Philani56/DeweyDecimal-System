﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ST10083213._PROG7312_POE___TASK_1.Model
{
    //--------------------------- Code Attrribution ---------------------------
    //This code was contribued in:
    //Author: Geeks for Geeks
    //Title: Radix Sort – Data Structures and Algorithms Tutorials
    //Year: 2023
    //URL: https://www.geeksforgeeks.org/radix-sort/

    //This code was contribued in:
    //Author: Mkyong
    //Title: Java – Generate random integers in a range
    //Year: August 19, 2015
    //URL: https://mkyong.com/java/java-generate-random-integers-in-a-range/

    class DALRandomCallNums
    {
        public static void generateCallNumbers()
        {
            String words = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            Random random = new Random();

            var nfi = new NumberFormatInfo { NumberGroupSeparator = "." };
            for (int i = 0; i < 10; i++)
            {
                double nums = (double)Math.Round(random.NextDouble() * 999, 2);
                Console.WriteLine(nums);

                //Double digit = random.Next(99);
                var check = (from x in ListNums.nums
                             where x.Equals(nums)
                             select x).ToList();

                if (check.Count > 0)
                {
                    ListNums.nums.Clear();
                    i = 0;
                }

                else
                {
                    ListNums.nums.Add(nums);
                }

                var stringChars = new char[3];
                for (int j = 0; j < stringChars.Length; j++)
                {
                    stringChars[j] = words[random.Next(words.Length)];
                }
                //--------------------------- End Attrribution ---------------------------

                //--------------------------- Code Attrribution ---------------------------
                //This code was contribued in:
                //Author: StackOverFlow
                //Title: How do I display a decimal value to 2 decimal places?
                //Year: 14 June 2018
                //URL: https://stackoverflow.com/questions/164926/how-do-i-display-a-decimal-value-to-2-decimal-places

                var finalString = new String(stringChars);
                
                
                String CallNumber = nums.ToString("0##.00", nfi) + finalString; //Convert nums to String

                ListNums.callNums.Add(CallNumber); //ListNums.nums[i] = random.Next(1000);

            }

            //--------------------------- End Attrribution ---------------------------

            for (int n = 0; n < 10; n++)
            {

            }


        }
        //Method to compare the user submitted list to sorted list
        public static Boolean CompareList(List<String> listCallNumsUser)
        {
            Boolean result = true;
            for (int i = 0; i < ListNums.callNums.Count; i++)
            {

                Console.WriteLine("Array 1: " + listCallNumsUser[i]);
                if (listCallNumsUser[i] != ListNums.callNums[i])
                {
                    result = false;
                    Console.Write(listCallNumsUser[i]);
                }
            }
            Console.WriteLine(result);
            return result;
        }
    }
}



