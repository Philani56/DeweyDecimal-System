﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10083213._PROG7312_POE___TASK_2.Model
{
    internal class Node
    {
        public Node leftNode { get; set; }
        public Node rightNode { get; set; }

        public CallNumber Data { get; set; }

        //Child int variable

        //--------------------------- Code Attrribution ----------------------------
        //This code was contribued in:
        //Author: OpenGenus IQ
        //Title: Select Random Node from Binary Tree
        //Year: 2023
        //URL: https://iq.opengenus.org/select-random-node-from-binary-tree/
        public int child { get; set; }
    }
        //--------------------------- END Attrribution ----------------------------
}
