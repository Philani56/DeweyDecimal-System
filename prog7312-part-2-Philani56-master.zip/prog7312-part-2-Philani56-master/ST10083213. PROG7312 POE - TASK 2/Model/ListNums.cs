﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10083213._PROG7312_POE___TASK_1.Model
{
    //Class with the static lists 
    class ListNums
    {
        public static List<double> nums = new List<double>(); // numbers
        public static List<string> callNums = new List<string>(); //letters
    }
}
