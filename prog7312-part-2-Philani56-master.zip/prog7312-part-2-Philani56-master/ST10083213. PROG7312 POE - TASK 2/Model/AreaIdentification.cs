﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10083213._PROG7312_POE___TASK_2.Model
{
    internal class AreaIdentification
    {
        //--------------------------- Code Attrribution ----------------------------
        //This code was contribued in:
        //Author: mkyong
        //Title: Java – Generate random integers in a range
        //Year: August 19, 2015
        //URL: https://mkyong.com/java/java-generate-random-integers-in-a-range/

        //This code was contribued in:
        //Author: Microsoft
        //Title: Math.Round Method
        //Year: 2023
        //URL: https://learn.microsoft.com/en-us/dotnet/api/system.math.round?view=net-7.0

        // Method to randomly generate Call Numbers

        public static void generateCallNumbers(int level)
        {
            // Initialize variables and clear the dictionary
            bool noDup = false;
            CallNumber.callNumbersDictionary.Clear();
            List<double> numsList = new List<double>();
            string words = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            Random random = new Random();
            var nfi = new NumberFormatInfo { NumberGroupSeparator = "." };

            // Continue generating call numbers until there are no duplicates
            while (noDup == false)
            {
                for (int i = 0; i < 7; i++)
                {
                    double nums = (double)Math.Round(random.NextDouble() * 999, 2);
                    Console.WriteLine(nums);
                    var check = (from x in numsList
                                 where x.Equals(nums)
                                 select x).ToList();

                    // Check for duplicate numbers, clear list if found
                    if (check.Count > 0)
                    {
                        numsList.Clear();
                        i = 0;
                    }
                    else
                    {
                        numsList.Add(nums);
                    }

                    // Generate a random string part
                    var stringChars = new char[3];
                    for (int j = 0; j < stringChars.Length; j++)
                    {
                        stringChars[j] = words[random.Next(words.Length)];
                    }
                    var finalString = new string(stringChars);

                    // Convert nums to a formatted string and get the area information
                    string CallNumber = nums.ToString("0##.00", nfi) + finalString;
                    getArea(nums, CallNumber, level);
                }

                // Check for duplicates in the dictionary
                var duplicatesValue = CallNumber.callNumbersDictionary.GroupBy(x => x.Value).Where(x => x.Count() > 1);

                if (duplicatesValue.Count() > 0)
                {
                    CallNumber.callNumbersDictionary.Clear();
                }
                else
                {
                    noDup = true;
                    break;
                }
            }
        }
        //--------------------------- End Attrribution ----------------------------
        //--------------------------- Code Attrribution ---------------------------
        //This code was contribued in:
        //Author: by Steve Gomez
        //Title: Switch Case
        //Year: 2023
        //URL: https://stackoverflow.com/questions/20147879/switch-case-can-i-use-a-range-instead-of-a-one-number

        // Method to get the description according to the Dewey Decimal System

        public static void getArea(double num, string CallNum, int level)
        {
            CallNumber number = new CallNumber();

            if (level == 1)
            {
                switch (num)
                {
                    case var _ when num < 100:
                        number.CallNum = CallNum;
                        //number.CallType = "General Works";
                        number.CallNumDescription = "General works";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 100 && num < 200:
                        number.CallNum = CallNum;
                        //number.CallType = "Philosophy";
                        number.CallNumDescription = "Philosophy";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 200 && num < 300:
                        number.CallNum = CallNum;
                        //number.CallType = "Religion";
                        number.CallNumDescription = "Religion";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 300 && num < 400:
                        number.CallNum = CallNum;
                        //number.CallType = "Social Sciences";
                        number.CallNumDescription = "Social Sciences";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 400 && num < 500:
                        number.CallNum = CallNum;
                        //number.CallType = "Language";
                        number.CallNumDescription = "Language";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 500 && num < 600:
                        number.CallNum = CallNum;
                        //number.CallType = "Science";
                        number.CallNumDescription = "Science";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 600 && num < 700:
                        number.CallNum = CallNum;
                        //number.CallType = "Technology";
                        number.CallNumDescription = "Technology";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 700 && num < 800:
                        number.CallNum = CallNum;
                        //number.CallType = "The Arts";
                        number.CallNumDescription = "The Arts";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 800 && num < 900:
                        number.CallNum = CallNum;
                        //number.CallType = "Literature";
                        number.CallNumDescription = "Literature";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 900 && num < 999:
                        number.CallNum = CallNum;
                        //number.CallType = "History and Geography";
                        number.CallNumDescription = "History and Geography";
                        CallNumber.callNumbersDictionary.Add(number.CallNum, number.CallNumDescription);
                        break;
                }
            }

            else if (level == 2)
            {
                // Declare a new class to get the level 2 descriptions
                Level2AreaDescription level2AreaDescription = new Level2AreaDescription();
                switch (num)
                {
                    case var _ when num < 100:
                        number.CallNum = CallNum;
                        //number.CallType = "General Works";
                        number.CallNumDescription = "General Works";
                        level2AreaDescription.getDesGenWorks(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 100 && num < 200:
                        number.CallNum = CallNum;
                        //number.CallType = "Philosophy";
                        number.CallNumDescription = "Philosophy";
                        level2AreaDescription.getDesPhilosophy(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 200 && num < 300:
                        number.CallNum = CallNum;
                        //number.CallType = "Religion";
                        number.CallNumDescription = "Religion";
                        level2AreaDescription.getDesReligion(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 300 && num < 400:
                        number.CallNum = CallNum;
                        //number.CallType = "Social Sciences";
                        number.CallNumDescription = "Social Sciences";
                        level2AreaDescription.getDesSocialSciences(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 400 && num < 500:
                        number.CallNum = CallNum;
                        //number.CallType = "Language";
                        number.CallNumDescription = "Language";
                        level2AreaDescription.getDesLanguage(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 500 && num < 600:
                        number.CallNum = CallNum;
                        //number.CallType = "Science";
                        number.CallNumDescription = "Science";
                        level2AreaDescription.getDesScience(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 600 && num < 700:
                        number.CallNum = CallNum;
                        //number.CallType = "Technology";
                        number.CallNumDescription = "Technology";
                        level2AreaDescription.getDesTechnology(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 700 && num < 800:
                        number.CallNum = CallNum;
                        //number.CallType = "The Arts";
                        number.CallNumDescription = "Arts";
                        level2AreaDescription.getDesTheArts(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 800 && num < 900:
                        number.CallNum = CallNum;
                        //number.CallType = "Literature";
                        number.CallNumDescription = "Literature";
                        level2AreaDescription.getDesLiterature(num, CallNum, number.CallNumDescription);
                        break;
                    case var _ when num >= 900 && num < 999:
                        number.CallNum = CallNum;
                        //number.CallType = "History and Geography";
                        number.CallNumDescription = "History and Geography";
                        level2AreaDescription.getDesHistoryGeography(num, CallNum, number.CallNumDescription);
                        break;
                }
                //--------------------------- End Attrribution ---------------------------
            }
        }
    }
}
