﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10083213._PROG7312_POE___TASK_2.Model
{
    public class CallNumber
    {
        // Dictionary to store call numbers as key-value pairs
        public static Dictionary<string, string> callNumbersDictionary = new Dictionary<string, string>();

        // Default constructor
        public CallNumber()
        {
            // No logic is implemented in the default constructor
        }

        // Parameterized constructor to initialize the CallNumber object
        public CallNumber(string callNum, int callNumInt, string callNumDescription)
        {
            // Initialize properties with provided values
            CallNum = callNum;
            CallNumInt = callNumInt;
            CallNumDescription = callNumDescription;
        }

        // Property to store the call number
        public string CallNum { get; set; }

        // Property for the call name (commented out, as it's not used in the code)
        // public string CallName { get; set; }

        // Property for the call type (commented out, as it's not used in the code)
        // public string CallType { get; set; }

        // Property to store the description of the call number
        public string CallNumDescription { get; set; }

        // Property to store the integer representation of the call number
        public int CallNumInt { get; set; }

        // Additional properties (commented out, as they are not used in the code)
        // public int MyProperty { get; set; }
    }
}